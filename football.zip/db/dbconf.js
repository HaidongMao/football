module.exports =
{  
  mysql: {   
  	connectionLimit: 50,
    host: '127.0.0.1',     
    user: 'root',   
    password: 'anna',  
    database:'football',
    port: 3306  
  }
};
